# 1xGoal starter (Flutter)

This is the first playable prototype scaffold for 1xGoal.

## Included
- Home screen
- Practice mode vs a simple CPU goalkeeper
- Five-shot round and score
- Private-room UI placeholder
- Faux-depth pitch/goal/players drawn with Flutter CustomPainter

## Not included yet
- Real image/sprite assets
- Real online matchmaking
- Actual private rooms
- Accounts, database, anti-cheat server
- Final physics and animation

## Run
1. Install/use a Flutter-enabled Android development environment.
2. Create a new Flutter project named `one_x_goal` (`flutter create one_x_goal`).
3. Replace its `pubspec.yaml` and `lib/main.dart` with the files from this starter.
4. Run `flutter pub get`.
5. Run `flutter run` or build with `flutter build apk`.

If you already have a Flutter project, back up your files before replacing them.

## Mobile-only workflow
If building directly on Android, make sure your environment has the Flutter SDK and Android build tools. GitHub stores the source code, but GitHub itself does not compile the APK unless you configure a GitHub Actions workflow or use a compatible cloud development environment.
