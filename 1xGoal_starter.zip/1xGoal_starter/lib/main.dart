import 'dart:math' as math;
import 'package:flutter/material.dart';

void main() => runApp(const OneXGoalApp());

const Color pitchGreen = Color(0xFF146B43);
const Color neonGreen = Color(0xFFB7F34A);
const Color night = Color(0xFF07131D);

class OneXGoalApp extends StatelessWidget {
  const OneXGoalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '1xGoal',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: night,
        colorScheme: ColorScheme.fromSeed(
          seedColor: neonGreen,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF102B39), night],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 18),
                const Icon(Icons.sports_soccer, size: 58, color: neonGreen),
                const SizedBox(height: 8),
                const Text(
                  '1xGOAL',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 38,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 4,
                  ),
                ),
                const Text(
                  'ONE SHOT. ONE SAVE. ONE WIN.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white60,
                    fontSize: 11,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 28),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(24),
                    child: CustomPaint(
                      painter: StadiumPainter(),
                      child: const Center(
                        child: Icon(
                          Icons.sports_soccer,
                          size: 74,
                          color: Colors.white24,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                _MenuButton(
                  icon: Icons.bolt,
                  title: 'QUICK MATCH',
                  subtitle: 'Online matchmaking • coming next',
                  onTap: () => _showInfo(context),
                ),
                const SizedBox(height: 10),
                _MenuButton(
                  icon: Icons.lock_outline,
                  title: 'PRIVATE ROOM',
                  subtitle: 'Play with a friend using a room code',
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const PrivateRoomScreen(),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                _MenuButton(
                  icon: Icons.sports,
                  title: 'PRACTICE VS CPU',
                  subtitle: 'Play a penalty shootout now',
                  primary: true,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const PracticeScreen(),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'PROTOTYPE 0.1 • ONLINE FEATURES ARE NOT CONNECTED YET',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white38, fontSize: 9),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showInfo(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Online matchmaking'),
        content: const Text(
          'This prototype currently includes offline practice. '
          'Online matchmaking will be connected after the game loop is tested.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}

class _MenuButton extends StatelessWidget {
  const _MenuButton({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.primary = false,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: primary ? neonGreen : Colors.white.withOpacity(0.07),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Icon(icon, color: primary ? night : neonGreen, size: 27),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: primary ? night : Colors.white,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: primary ? night.withOpacity(0.72) : Colors.white60,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right,
                color: primary ? night : Colors.white54,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PracticeScreen extends StatefulWidget {
  const PracticeScreen({super.key});

  @override
  State<PracticeScreen> createState() => _PracticeScreenState();
}

class _PracticeScreenState extends State<PracticeScreen> {
  final math.Random _random = math.Random();
  int _playerGoals = 0;
  int _cpuGoals = 0;
  int _shots = 0;
  bool _busy = false;
  String _message = 'Choose a target in the goal to shoot.';
  int? _keeperDive;
  int? _ballTarget;
  bool _showBall = false;

  Future<void> _shoot(int target) async {
    if (_busy || _shots >= 5) return;
    setState(() {
      _busy = true;
      _keeperDive = _random.nextInt(3);
      _ballTarget = target;
      _showBall = true;
      _message = 'SHOOTING...';
    });

    await Future<void>.delayed(const Duration(milliseconds: 750));
    if (!mounted) return;

    final saved = _keeperDive == target && _random.nextInt(100) < 78;
    setState(() {
      _shots++;
      if (!saved) {
        _playerGoals++;
        _message = 'GOAL! ⚽';
      } else {
        _message = 'SAVED! 🧤';
      }
    });

    await Future<void>.delayed(const Duration(milliseconds: 800));
    if (!mounted) return;
    setState(() {
      _busy = false;
      _keeperDive = null;
      _ballTarget = null;
      _showBall = false;
      if (_shots >= 5) {
        _message = _playerGoals > _cpuGoals
            ? 'YOU WIN! • Final score $_playerGoals - $_cpuGoals'
            : _playerGoals < _cpuGoals
                ? 'CPU WINS • Final score $_playerGoals - $_cpuGoals'
                : 'DRAW • Final score $_playerGoals - $_cpuGoals';
      } else {
        _message = 'Choose your next shot.';
      }
    });
  }

  void _reset() {
    setState(() {
      _playerGoals = 0;
      _cpuGoals = 0;
      _shots = 0;
      _busy = false;
      _message = 'Choose a target in the goal to shoot.';
      _keeperDive = null;
      _ballTarget = null;
      _showBall = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PRACTICE MODE'),
        backgroundColor: Colors.transparent,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
          child: Column(
            children: [
              Row(
                children: [
                  _ScoreCard(label: 'YOU', score: _playerGoals),
                  const SizedBox(width: 10),
                  _ScoreCard(label: 'CPU', score: _cpuGoals),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(13),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text(
                        'SHOT ${math.min(_shots + 1, 5)} / 5',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(22),
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTapUp: (details) {
                          if (_shots < 5 && !_busy) {
                            final x = details.localPosition.dx /
                                constraints.maxWidth;
                            final y = details.localPosition.dy /
                                constraints.maxHeight;
                            if (y < 0.63 && y > 0.16) {
                              final target = x < 0.36 ? 0 : x > 0.64 ? 2 : 1;
                              _shoot(target);
                            }
                          }
                        },
                        child: CustomPaint(
                          painter: PenaltyPainter(
                            keeperDive: _keeperDive,
                            ballTarget: _ballTarget,
                            showBall: _showBall,
                          ),
                          child: const SizedBox.expand(),
                        ),
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.07),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Text(
                  _message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.home_outlined),
                      label: const Text('MENU'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _reset,
                      icon: const Icon(Icons.replay),
                      label: const Text('RESTART'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              const Text(
                'Tap the left, center, or right side of the goal to shoot.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white54, fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ScoreCard extends StatelessWidget {
  const _ScoreCard({required this.label, required this.score});
  final String label;
  final int score;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          children: [
            Text(label, style: const TextStyle(color: Colors.white54, fontSize: 10)),
            Text(
              '$score',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
            ),
          ],
        ),
      ),
    );
  }
}

class PrivateRoomScreen extends StatefulWidget {
  const PrivateRoomScreen({super.key});

  @override
  State<PrivateRoomScreen> createState() => _PrivateRoomScreenState();
}

class _PrivateRoomScreenState extends State<PrivateRoomScreen> {
  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('PRIVATE ROOM')),
      body: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.groups_2_outlined, size: 70, color: neonGreen),
            const SizedBox(height: 16),
            const Text(
              'Play with a friend',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 8),
            const Text(
              'The room interface is prepared, but room creation and joining '
              'need the online backend in a later step.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60),
            ),
            const SizedBox(height: 26),
            TextField(
              controller: _controller,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(
                labelText: 'Room code',
                hintText: 'Example: GOAL24',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Online rooms will be connected in a later version.'),
                  ),
                );
              },
              child: const Text('JOIN ROOM'),
            ),
            OutlinedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Room creation needs the online backend.'),
                  ),
                );
              },
              child: const Text('CREATE ROOM'),
            ),
          ],
        ),
      ),
    );
  }
}

class StadiumPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF142D43), Color(0xFF07131D)],
        ).createShader(rect),
    );

    final horizon = size.height * 0.38;
    final lights = Paint()..color = const Color(0xFFB7F34A).withOpacity(0.75);
    for (int i = 0; i < 12; i++) {
      final x = size.width * (i + 0.5) / 12;
      canvas.drawCircle(Offset(x, horizon - 20), 2.2, lights);
    }

    final field = Path()
      ..moveTo(size.width * 0.28, horizon)
      ..lineTo(size.width * 0.72, horizon)
      ..lineTo(size.width * 1.12, size.height)
      ..lineTo(size.width * -0.12, size.height)
      ..close();
    canvas.drawPath(field, Paint()..color = pitchGreen);

    final linePaint = Paint()
      ..color = Colors.white.withOpacity(0.28)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    canvas.drawLine(
      Offset(size.width * 0.28, horizon),
      Offset(size.width * -0.12, size.height),
      linePaint,
    );
    canvas.drawLine(
      Offset(size.width * 0.72, horizon),
      Offset(size.width * 1.12, size.height),
      linePaint,
    );
    canvas.drawLine(
      Offset(size.width * 0.28, horizon),
      Offset(size.width * 0.72, horizon),
      linePaint,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * 0.5, size.height * 0.82),
        width: size.width * 0.52,
        height: size.height * 0.13,
      ),
      linePaint,
    );

    final goal = Rect.fromLTWH(
      size.width * 0.28,
      size.height * 0.22,
      size.width * 0.44,
      size.height * 0.2,
    );
    canvas.drawRect(goal, Paint()..color = Colors.white.withOpacity(0.07));
    canvas.drawRect(
      goal,
      Paint()
        ..color = Colors.white.withOpacity(0.9)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3,
    );
    for (int i = 1; i < 8; i++) {
      final x = goal.left + goal.width * i / 8;
      canvas.drawLine(
        Offset(x, goal.top),
        Offset(x, goal.bottom),
        Paint()..color = Colors.white.withOpacity(0.18),
      );
    }
    for (int i = 1; i < 5; i++) {
      final y = goal.top + goal.height * i / 5;
      canvas.drawLine(
        Offset(goal.left, y),
        Offset(goal.right, y),
        Paint()..color = Colors.white.withOpacity(0.18),
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class PenaltyPainter extends CustomPainter {
  PenaltyPainter({
    required this.keeperDive,
    required this.ballTarget,
    required this.showBall,
  });

  final int? keeperDive;
  final int? ballTarget;
  final bool showBall;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF142D43), Color(0xFF07131D), Color(0xFF0B3C2B)],
        ).createShader(rect),
    );

    final horizon = size.height * 0.43;
    final field = Path()
      ..moveTo(size.width * 0.31, horizon)
      ..lineTo(size.width * 0.69, horizon)
      ..lineTo(size.width * 1.2, size.height)
      ..lineTo(size.width * -0.2, size.height)
      ..close();
    canvas.drawPath(field, Paint()..color = pitchGreen);

    final stripePaint = Paint()..color = const Color(0xFF0B5B39).withOpacity(0.6);
    for (int i = 0; i < 6; i++) {
      final topY = horizon + (size.height - horizon) * i / 6;
      final bottomY = horizon + (size.height - horizon) * (i + 1) / 6;
      final leftTop = size.width * (0.31 - 0.51 * i / 6);
      final rightTop = size.width * (0.69 + 0.51 * i / 6);
      final leftBottom = size.width * (0.31 - 0.51 * (i + 1) / 6);
      final rightBottom = size.width * (0.69 + 0.51 * (i + 1) / 6);
      if (i.isEven) {
        final p = Path()
          ..moveTo(leftTop, topY)
          ..lineTo(rightTop, topY)
          ..lineTo(rightBottom, bottomY)
          ..lineTo(leftBottom, bottomY)
          ..close();
        canvas.drawPath(p, stripePaint);
      }
    }

    final goal = Rect.fromLTWH(
      size.width * 0.14,
      size.height * 0.12,
      size.width * 0.72,
      size.height * 0.42,
    );
    canvas.drawRect(goal, Paint()..color = Colors.white.withOpacity(0.06));
    final netPaint = Paint()
      ..color = Colors.white.withOpacity(0.2)
      ..strokeWidth = 1;
    for (int i = 1; i < 13; i++) {
      final x = goal.left + goal.width * i / 13;
      canvas.drawLine(Offset(x, goal.top), Offset(x, goal.bottom), netPaint);
    }
    for (int i = 1; i < 8; i++) {
      final y = goal.top + goal.height * i / 8;
      canvas.drawLine(Offset(goal.left, y), Offset(goal.right, y), netPaint);
    }
    canvas.drawRect(
      goal,
      Paint()
        ..color = Colors.white
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4,
    );

    // Goalkeeper: simple placeholder silhouette, replaced by sprite art later.
    final keeperX = keeperDive == null
        ? size.width * 0.5
        : size.width * (keeperDive == 0 ? 0.30 : keeperDive == 2 ? 0.70 : 0.5);
    final keeperY = size.height * 0.37;
    final keeperPaint = Paint()..color = const Color(0xFFFFB84D);
    canvas.drawCircle(Offset(keeperX, keeperY - 24), 10, keeperPaint);
    final bodyPaint = Paint()
      ..color = const Color(0xFFED3B43)
      ..strokeWidth = 13
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(keeperX, keeperY - 10),
      Offset(keeperX, keeperY + 20),
      bodyPaint,
    );
    final armY = keeperY - 3;
    final armEndX = keeperDive == 0
        ? keeperX - 35
        : keeperDive == 2
            ? keeperX + 35
            : keeperX;
    canvas.drawLine(
      Offset(keeperX, armY),
      Offset(armEndX, armY - (keeperDive == 1 ? 10 : 5)),
      bodyPaint..strokeWidth = 8,
    );
    final legPaint = Paint()
      ..color = const Color(0xFF15243A)
      ..strokeWidth = 8
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(keeperX, keeperY + 20),
      Offset(keeperX - 10, keeperY + 42),
      legPaint,
    );
    canvas.drawLine(
      Offset(keeperX, keeperY + 20),
      Offset(keeperX + 10, keeperY + 42),
      legPaint,
    );

    // Kicker silhouette in the foreground.
    final kickerX = size.width * 0.5;
    final kickerY = size.height * 0.79;
    canvas.drawCircle(
      Offset(kickerX, kickerY - 22),
      11,
      Paint()..color = const Color(0xFFE8B68C),
    );
    final kickerBody = Paint()
      ..color = const Color(0xFF4AA8FF)
      ..strokeWidth = 15
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(kickerX, kickerY - 8),
      Offset(kickerX - 2, kickerY + 23),
      kickerBody,
    );
    final legs = Paint()
      ..color = const Color(0xFF17233A)
      ..strokeWidth = 9
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(kickerX - 2, kickerY + 20),
      Offset(kickerX - 19, kickerY + 43),
      legs,
    );
    canvas.drawLine(
      Offset(kickerX - 2, kickerY + 20),
      Offset(kickerX + 18, kickerY + 40),
      legs,
    );

    final ballX = showBall && ballTarget != null
        ? size.width * (ballTarget == 0 ? 0.28 : ballTarget == 2 ? 0.72 : 0.5)
        : size.width * 0.5;
    final ballY = showBall ? size.height * 0.38 : size.height * 0.88;
    canvas.drawCircle(
      Offset(ballX, ballY),
      showBall ? 9 : 12,
      Paint()..color = Colors.white,
    );
    canvas.drawCircle(
      Offset(ballX, ballY),
      showBall ? 9 : 12,
      Paint()
        ..color = Colors.black54
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );

    final labelStyle = const TextStyle(
      color: Colors.white70,
      fontSize: 11,
      fontWeight: FontWeight.w800,
      letterSpacing: 1,
    );
    _drawText(canvas, 'LEFT', Offset(size.width * 0.18, size.height * 0.57), labelStyle);
    _drawText(canvas, 'CENTER', Offset(size.width * 0.44, size.height * 0.57), labelStyle);
    _drawText(canvas, 'RIGHT', Offset(size.width * 0.75, size.height * 0.57), labelStyle);
  }

  void _drawText(Canvas canvas, String text, Offset offset, TextStyle style) {
    final painter = TextPainter(
      text: TextSpan(text: text, style: style),
      textDirection: TextDirection.ltr,
    )..layout();
    painter.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant PenaltyPainter oldDelegate) =>
      oldDelegate.keeperDive != keeperDive ||
      oldDelegate.ballTarget != ballTarget ||
      oldDelegate.showBall != showBall;
}
